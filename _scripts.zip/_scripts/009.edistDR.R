require(rgdal)
require(raster)

#Calculate the size of the DR, of the convexhull in km2, of the native area, and of the herbarium samples
#based on the area of the cells

edistDR <- function(bdir, spID) {
	
	idir <- paste(bdir, "/maxent_modeling", sep="")
	ddir <- paste(bdir, "/samples_calculations", sep="")
	pcdir <- paste(bdir, "/biomod_modeling/current-clim/wwf_eco", sep="")
	
	#Creating the directories
	if (!file.exists(ddir)) {
		dir.create(ddir)
	}
	
	spOutFolder <- paste(ddir, "/", spID, sep="")
	if (!file.exists(spOutFolder)) {
		dir.create(spOutFolder)
	}
	
	#Read the thresholded raster (PA), multiply it by the area raster and sum up those cells that are != 0
	cat("Taxon", spID, "\n")
	spFolder <- paste(idir, "/models/", sep="")
	projFolder <- spFolder
	
	cat("Loading wwf terrestrial ecosystems \n")
	pc1 <- raster(paste(pcdir,"/wwf_eco_terr.tif",sep=""))
 
	#Edist of the DR
	cat("Reading presence/absence surface \n")
	grd <- paste(spID, "_worldclim2_5_EMN_PA.tif", sep="")
	spList <- read.csv(paste(bdir, "/summary-files/taxaForRichness.csv", sep=""))
	isValid <- spList$IS_VALID[which(spList$TAXON == paste(spID))]
	
	if (isValid == 1) {
    grd <- raster(paste(projFolder,"/",grd,sep=""))
		
		cat("Env. distribution of the DR \n")
		grda <- grd * pc1 #PC1
		edistDR1 <- unique(grda[])
		edistDR1 <- edistDR1[which(edistDR1 != 0 & !is.na(edistDR1))]
		rm(grda)
				
		rm(grd)
	} else {
		edistDR1 <- NULL
	}
	
	#Edist of the convex-hull
	if (file.exists(paste(ddir, "/", spID, "/convex-hull.tif", sep=""))) {
		cat("Reading convex hull \n")
    grd <- raster(paste(ddir, "/", spID, "/convex-hull.tif",sep=""))
		
		cat("Env. distribution of the convex hull \n")
		grda <- grd * pc1
		edistCH1 <- unique(grda[])
		edistCH1 <- edistCH1[which(edistCH1 != 0 & !is.na(edistCH1))]
		rm(grda)
		
		rm(grd)
	} else {
		edistCH1 <- NULL
# 		edistCH2 <- NULL
	}
  
	#Edist of the native area
# 	naFolder <- paste(bdir, "/biomod_modeling/native-areas/asciigrids/", spID, sep="")
# 	if (file.exists(paste(naFolder, "/narea.tif", sep=""))) {
# 		cat("Reading native area \n")
#     grd <- raster(paste(naFolder,"/narea.tif",sep=""))
# 		
# 		cat("Env. distribution of the native area \n")
# 		grda <- grd * pc1
# 		edistNA1 <- unique(grda[])
# 		edistNA1 <- edistNA1[which(edistNA1 != 0 & !is.na(edistNA1))]
# 		rm(grda)
# 		
# 		rm(grd)
# 	} else {
		edistNA1 <- NULL
# 	}
	
	#Edist of the herbarium samples CA50
	cat("Reading h-samples buffer \n")
	if (file.exists(paste(ddir, "/", spID, "/hsamples-buffer.tif", sep=""))) {
		grd <- raster(paste(ddir, "/", spID,"/hsamples-buffer.tif",sep=""))
		
		cat("Env. distribution of h-samples buffer \n")
		grda <- grd * pc1
		edistHB1 <- unique(grda[])
		edistHB1 <- edistHB1[which(edistHB1 != 0 & !is.na(edistHB1))]
		rm(grda)
		
		rm(grd)
	} else {
		edistHB1 <- NULL
	}
	
	#Size of the germplasm samples CA50
	cat("Reading g-samples buffer \n")
	if (file.exists(paste(ddir, "/", spID, "/gsamples-buffer.tif", sep=""))) {
	  grd <- raster(paste(ddir, "/", spID,"/gsamples-buffer.tif",sep=""))
		
		cat("Env. distribution of g-samples buffer \n")
		grda <- grd * pc1
		edistGB1 <- unique(grda[])
		edistGB1 <- edistGB1[which(edistGB1 != 0 & !is.na(edistGB1))]
		rm(grda)
		
		rm(grd)
	} else {
		edistGB1 <- NULL
	}
	#Writing results
	outDF <- data.frame(DRDist.PC1=length(edistDR1), CHDist.PC1=length(edistCH1), NADist.PC1=length(edistNA1), HBDist.PC1=length(edistHB1), GBDist.PC1=length(edistGB1))
  
	write.csv(outDF, paste(spOutFolder, "/edist_wwf.csv", sep=""), quote=F, row.names=F)
	return(outDF)
}


summarizeDR_env <- function(idir) {
	
	ddir <- paste(idir, "/samples_calculations", sep="")
	
	odir <- paste(idir, "/summary-files", sep="")
	if (!file.exists(odir)) {
		dir.create(odir)
	}
	
	spList <- list.files(paste(idir, "/occurrence_files", sep=""))
	
	sppC <- 1
	for (spp in spList) {
		spp <- unlist(strsplit(spp, ".", fixed=T))[1]
		fdName <- spp #paste("sp-", spp, sep="")
		spFolder <- paste(idir, "/maxent_modeling/models/", sep="")
		spOutFolder <- paste(ddir, "/", spp, sep="")
		
		if (file.exists(spFolder)) {
			
# 			res <- edistDR(idir, spp)
			
			metFile <- paste(spOutFolder, "/edist_wwf.csv", sep="")
			metrics <- read.csv(metFile)
			metrics <- cbind(taxon=spp, metrics)
			
			if (sppC == 1) {
				outSum <- metrics
			} else {
				outSum <- rbind(outSum, metrics)
			}
			sppC <- sppC + 1
		} else {
			cat("The taxon was never modeled \n")
		}
	}
	
	outFile <- paste(odir, "/edist_wwf.csv", sep="")
	write.csv(outSum, outFile, quote=F, row.names=F)
	return(outSum)
}
